package com.BookstoreAPI.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.BookstoreAPI.Entity.Customer;
import com.BookstoreAPI.Service.CustomerService;

@Controller
public class CustomerController {

	@Autowired
	private CustomerService customerService;

	@PostMapping("/save_customer")
	public String addCustomer(@ModelAttribute Customer c) {
		customerService.save(c);
		return "redirect:/available_books";
	}

	// Registration endpoint
	@PostMapping("/register")
	public ModelAndView registerCustomer(@RequestParam String name, @RequestParam String email,
			@RequestParam String password) {
		boolean registered = customerService.registerCustomer(name, email, password);
		if (registered) {
			return new ModelAndView("home"); // Replace "home" with the view you want to redirect to
		} else {
			ModelAndView modelAndView = new ModelAndView("error"); // Replace "error" with the error view
			modelAndView.addObject("message", "Email already exists.");
			return modelAndView;
		}
	}

	// Login endpoint
	@PostMapping("/login")
	public ResponseEntity<String> login(@RequestParam String email, @RequestParam String password) {
		boolean authenticated = customerService.authenticateCustomer(email, password);
		if (authenticated) {
			return ResponseEntity.ok("Login successful!");
		} else {
			return ResponseEntity.status(401).body("Invalid email or password.");
		}
	}
}
