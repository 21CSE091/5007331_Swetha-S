package com.BookstoreAPI.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.BookstoreAPI.DTO.BookDTO;
import com.BookstoreAPI.Entity.Book;
import com.BookstoreAPI.Exception.ResourceNotFoundException;
import com.BookstoreAPI.Mapper.BookMapper;
import com.BookstoreAPI.Repository.BookRepository;

import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import io.swagger.v3.oas.annotations.Operation;

@Service
public class BookService {

	@Autowired
	private BookRepository bookRepository;
	
	private BookMapper bookMapper;

	public Book createBook(Book book) {
		return bookRepository.save(book);
	}

	public List<Book> getAllBooks() {
		return bookRepository.findAll();
	}

	public Book getBookbyId(int id) {
		return bookRepository.findById(id).orElseThrow(() -> new RuntimeException("Book not found with id: " + id));
	}

	public Book updateBook(Book book) {
		if (bookRepository.existsById(book.getId())) {
			return bookRepository.save(book);
		} else {
			throw new RuntimeException("Book not found with id: " + book.getId());
		}
	}

	/*public void deleteBook(int id) {
		if (bookRepository.existsById(id)) {
			bookRepository.deleteById(id);
		} else {
			throw new RuntimeException("Book not found with id: " + id);
		}
	}*/

	public List<Book> searchBooks(String title, String author) {
		if (title != null && author != null) {
			return bookRepository.findByTitleAndAuthor(title, author);
		} else if (title != null) {
			return bookRepository.findByTitle(title);
		} else if (author != null) {
			return bookRepository.findByAuthor(author);
		} else {
			return bookRepository.findAll();
		}
	}
	
	 @Operation(summary = "Create a new book")
	 @Transactional
	    public BookDTO createBook(@RequestBody @Valid BookDTO bookDTO) {
	        Book book = bookMapper.toEntity(bookDTO);
	        Book savedBook = bookRepository.save(book);
	        return bookMapper.toDto(savedBook);
	    }

	    public BookDTO getBook(int id) {
	        Book book = bookRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Book not found"));
	        return bookMapper.toDto(book);
	    }

	    @Transactional
	    public BookDTO updateBook(int id, BookDTO bookDTO) {
	        Book existingBook = bookRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Book not found"));
	        existingBook.setTitle(bookDTO.getTitle());
	        existingBook.setAuthor(bookDTO.getAuthor());
	        existingBook.setPrice(bookDTO.getPrice());
	        Book updatedBook = bookRepository.save(existingBook);
	        return bookMapper.toDto(updatedBook);
	    }

	    @Transactional
	    public void deleteBook(int id) {
	        bookRepository.deleteById(id);
	    }
	}

}
