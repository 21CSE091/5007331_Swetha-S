package com.BookstoreAPI.Service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.BookstoreAPI.Entity.Customer;
import com.BookstoreAPI.Repository.CustomerRepository;

@Service
public class CustomerService {

	@Autowired
	private CustomerRepository customerRepository;

	public void save(Customer c) {
		customerRepository.save(c);
	}

	public boolean registerCustomer(String name, String email, String password) {
		if (customerRepository.findByEmail(email).isPresent()) {
			return false;
		}
		Customer customer = new Customer();
		customer.setName(name);
		customer.setEmail(email);
		customer.setPassword(password);
		customerRepository.save(customer);
		return true;
	}

	public boolean authenticateCustomer(String email, String password) {
		Optional<Customer> customer = customerRepository.findByEmail(email);
		return customer.isPresent() && customer.get().getPassword().equals(password);
	}
}
