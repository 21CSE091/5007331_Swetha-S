package com.BookstoreAPI.Exception;

public class MissingServletRequestParameterException {

}
