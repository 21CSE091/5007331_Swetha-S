package com.example.EmployeeManagementSystem.Repository;
import com.example.EmployeeManagementSystem.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee,String>{
	/*
	 @Query("SELECT e from Employee e where e.name=:name")
	 * */

	@Query(name="Employee.findByName")
	List<Employee> findByName(String Name);
	
	/*
	@Query("SELECT e from Employee e where e.department=:department")
	*/
	@Query(name="Employee.findByDepartment")
	List<Employee> findByDepartment(String Dept);
	
	/*With Pagination
	 * Page<Employee> findByName(String name,Pageable pageable);
	 *
	 * Page<Employee> findByDepartment(String dept,Pageable pageable); 
	 * */
}
