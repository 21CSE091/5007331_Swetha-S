package com.example.EmployeeManagementSystem.Controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import com.example.EmployeeManagementSystem.*;
import com.example.EmployeeManagementSystem.Service.EmployeeService;

import java.util.List;

@RestController
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    @PostMapping("/employees")
    public Employee createEmployee(@RequestBody Employee employee) {
        return employeeService.saveEmployee(employee);
    }

    @GetMapping("/employees")
    public List<Employee> getAllEmployees() {
        return employeeService.getAllEmployees();
    }
    
    /*Pagination
     public ResponseEntity<Page<Employee>> getEmployeesByName(
            @RequestParam String Name,
            @RequestParam int page,
            @RequestParam int size,
            @RequestParam(defaultValue = "Name") String sortBy,
            @RequestParam(defaultValue = "asc") String sortDirection) {
        Page<Employee> employees = employeeService.getEmployeesByName(Name, page, size, sortBy, sortDirection);
        return new ResponseEntity<>(employees, HttpStatus.OK);
    }

    // Get paginated and sorted employees by department ID
    @GetMapping("/byDepartmentId")
    public ResponseEntity<Page<Employee>> getEmployeesByDepartment(
            @RequestParam String department,
            @RequestParam int page,
            @RequestParam int size,
            @RequestParam(defaultValue = "Name") String sortBy,
            @RequestParam(defaultValue = "asc") String sortDirection) {
        Page<Employee> employees = employeeService.getEmployeesByDepartment(department, page, size, sortBy, sortDirection);
        return new ResponseEntity<>(employees, HttpStatus.OK);
    } 
     */
}
