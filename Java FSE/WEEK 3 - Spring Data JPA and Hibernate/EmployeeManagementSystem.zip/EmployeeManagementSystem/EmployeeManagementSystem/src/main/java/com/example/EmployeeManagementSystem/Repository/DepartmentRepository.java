package com.example.EmployeeManagementSystem.Repository;
import com.example.EmployeeManagementSystem.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.jpa.repository.Query;
public interface DepartmentRepository extends JpaRepository<Department,String>{
	/*Query 
	@Query("SELECT d from Department d where d.name=:name")
	*/
	//Named Query
	@Query(name="Department.findByName")
	Department findByName(@Param("name")String Name);
}
