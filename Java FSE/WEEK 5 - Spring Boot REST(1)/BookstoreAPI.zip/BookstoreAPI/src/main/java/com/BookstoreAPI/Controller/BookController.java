package com.BookstoreAPI.Controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.server.EntityLinks;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.BookstoreAPI.DTO.BookDTO;
import com.BookstoreAPI.Entity.Book;
import com.BookstoreAPI.Entity.BookResource;
import com.BookstoreAPI.Entity.MyBookList;
import com.BookstoreAPI.Mapper.BookMapper;
import com.BookstoreAPI.Service.BookService;
import com.BookstoreAPI.Service.MyBookListService;

@Controller
public class BookController {

	@Autowired
	private BookService bookService;
	@Autowired
	private MyBookListService myBookService;

	private BookMapper bookMapper;

	@GetMapping("/")
	public String home() {
		return "home";
	}

	@GetMapping("/add_book")
	public String addBooks() {
		return "add_book";
	}

	/*
	 * @PostMapping("/save") public String addBook(@ModelAttribute Book b) {
	 * bookService.save(b); return "redirect:/available_books"; }
	 */

	@PostMapping("/save")
	public String addBook(@ModelAttribute BookDTO bookDTO, Model model) {
		// Convert DTO to Entity
		Book book = bookMapper.toEntity(bookDTO);
		// Save the book and convert back to DTO
		Book createdBook = bookService.createBook(book);
		model.addAttribute("book", bookMapper.toDto(createdBook));
		return "redirect:/available_books"; // Redirect to the books list page
	}

	@GetMapping("/my_books")
	public String getMyBooks(Model model) {
		List<MyBookList> list = myBookService.getAllMyBooks();
		model.addAttribute("book", list);
		return "myBooks";
	}

	@GetMapping("/{id}")
	public ResponseEntity<BookDTO> getBookById(@PathVariable int id) {
		// Fetch the book by ID and convert to DTO
		Book book = bookService.getBookbyId(id);
		return ResponseEntity.ok(bookMapper.toDto(book));
	}

	@PutMapping("/{id}")
	public ResponseEntity<BookDTO> updateBook(@PathVariable int id, @RequestBody BookDTO bookDTO) {
		// Convert DTO to Entity and set the ID
		Book book = bookMapper.toEntity(bookDTO);
		book.setId(id);
		// Update the book and convert back to DTO
		Book updatedBook = bookService.updateBook(book);
		return ResponseEntity.ok(bookMapper.toDto(updatedBook));
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteBook(@PathVariable int id) {
		// Delete the book by ID
		bookService.deleteBook(id);
		return ResponseEntity.noContent().build();
	}

	@GetMapping("/available_books")
	public ResponseEntity<List<BookDTO>> getAllBooks() {
		// Fetch all books and convert to DTOs
		List<Book> books = bookService.getAllBooks();
		List<BookDTO> bookDTOs = books.stream().map(bookMapper::toDto).collect(Collectors.toList());
		return ResponseEntity.ok(bookDTOs);
	}

	/*
	 * @GetMapping("/available_books") public ModelAndView getAllBooks() {
	 * List<Book> list = bookService.getAllBooks(); ModelAndView mv = new
	 * ModelAndView(); mv.setViewName("bookList"); mv.addObject("book", list);
	 * 
	 * return new ModelAndView("BookList", "book", list); }
	 */

	@Autowired
	private EntityLinks entityLinks;

	@GetMapping("/{id}")
	public ResponseEntity<BookResource> getBook(@PathVariable int id) {
		BookDTO bookDTO = bookService.getBook(id);
		BookResource bookResource = new BookResource();
		bookResource.setId(bookDTO.getId());
		bookResource.setTitle(bookDTO.getTitle());
		bookResource.setAuthor(bookDTO.getAuthor());
		bookResource.setPrice(bookDTO.getPrice());
		bookResource.add(entityLinks.linkToItemResource(BookResource.class, id));
		return ResponseEntity.ok(bookResource);
	}

}
