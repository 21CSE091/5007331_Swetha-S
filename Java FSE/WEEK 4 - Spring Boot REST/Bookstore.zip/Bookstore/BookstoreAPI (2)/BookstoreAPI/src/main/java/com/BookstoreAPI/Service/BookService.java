package com.BookstoreAPI.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.BookstoreAPI.Entity.Book;
import com.BookstoreAPI.Repository.BookRepository;

@Service
public class BookService {

	@Autowired
	private BookRepository bookrepository;

	public void save(Book b) {
		bookrepository.save(b);
	}

	public List<Book> getAllBook() {
		return bookrepository.findAll();
	}

	public Book getBookbyId(int id) {
		return bookrepository.findById(id).get();
	}

	public List<Book> searchBooks(String title, String author) {
		if (title != null && author != null) {
			return bookrepository.findByTitleAndAuthor(title, author);
		} else if (title != null) {
			return bookrepository.findByTitle(title);
		} else if (author != null) {
			return bookrepository.findByAuthor(author);
		} else {
			return bookrepository.findAll();
		}
	}	
}
