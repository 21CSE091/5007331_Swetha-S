package com.BookstoreAPI.Exception;

public class BookNotFound extends RuntimeException {
	public BookNotFound(String message) {
		super(message);
	}
}
